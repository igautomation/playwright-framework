// src/tests/ui/e2e/full-e2e.spec.js

require('module-alias/register');
const { test, expect } = require('@fixtures/combined');

const LoginPage = require('@pages/LoginPage');
const HomePage = require('@pages/HomePage');

test('E2E Flow: Login -> Navigate -> Verify Section', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const homePage = new HomePage(page);

  await page.goto('https://automationexercise.com/login');
  
  await loginPage.login('testuser', 'password123');

  const isLoginSuccessful = await loginPage.verifyLoginSuccess();
  expect(isLoginSuccessful).toBeTruthy();

  await homePage.navigateToSection('Products');

  const navLinks = await homePage.getNavLinks();
  expect(navLinks).toContain('Products');
});
